from typing import TypeVar


VisitorResult = TypeVar("VisitorResult")