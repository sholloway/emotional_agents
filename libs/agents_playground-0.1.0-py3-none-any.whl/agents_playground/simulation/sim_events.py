from enum import Enum

class SimulationEvents(Enum):
  WINDOW_CLOSED = 'WINDOW_CLOSED'